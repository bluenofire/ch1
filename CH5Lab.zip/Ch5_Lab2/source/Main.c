#include<stdio.h>
#include<stdlib.h>

#define ISSUES 5
#define RATINGS 10

void recordResponse(int issue, int rating);
void highestRatings();
void lowestRatings();
float averageRating();
void displayResults();

int response[ISSUES][RATINGS];
const char *topics[ISSUES] = { "Gloable Warming","The Economy",
								"War","Healthy Care","Education" };

int main()
{
	int response, i;
	do {
		printf("Please rate the following topics on a scale from 1 - 10"
			"\n 1 = least important, 10 = most important\n");

		for (i = 0; i < ISSUES; i++) {
			do {
				printf("%s? ", topics[i]);
				scanf_s("%d", &response);
			} while (response < 1 || response > 10);
			recordResponse(i, response);
		}
		printf("Enter 1 to stop. Enter 0 to rate the issues again.");
		scanf_s("%d", &response);
	} while (response != 1);
	displayResults();
	system("pause");
	return 0;
}

void recordResponse(int issue, int rating)
{
	response[issue][rating - 1]++;
}


void highestRatings()
{
	int i, j;
	int hr = 0;
	int ht = 0;

	for (i = 0; i < ISSUES; i++) {
		int tr = 0;
		for (j = 0; j < RATINGS; j++) {
			tr += response[i][j] * (j + 1);			
		}
		if (hr < tr)
		{
			hr = tr;
			ht = i;
		}
	}
	printf("The highest rated topic was ");
	printf("%s",topics[ht]);
	printf("with a total rating of %d\n",hr);
}

void lowestRatings()
{
	int i, j;
	int lr = 0;
	int lt = 0;

	for (i = 0; i < ISSUES; i++) {
		int tr = 0;
		for (j = 0; j < RATINGS; j++) {
			tr += response[i][j] * (j + 1);
		}
		if (i == 0)
		{
			lr = tr;
		}		
		if (lr > tr)
		{
			lr = tr;
			lt = i;
		}
	}
	printf("The lowest rated topic was ");
	printf("%s", topics[lt]);
	printf("with a total rating of %d\n", lr);
}

float averageRating(int issue)
{
	int i;
	float total = 0;
	int c = 0;

	for (i = 0; i < RATINGS; i++) {
				
		if (response[issue][i] != 0)
		{
			total += response[issue][i] * (i + 1);
			c += response[issue][i];
		}
	}
	return total / c;
}


void displayResults()
{
	int i, j;

	printf("%20s","topic");
	for (i = 0; i < RATINGS; i++)
	{
		printf("%4d", i);
	}
	printf("%20s", "Average Rating");

	for (i = 0; i <ISSUES; i++)
	{
		printf("%20s", topics[i]);

		for (j = 0; j < RATINGS; j++) {
			printf("%4d", response[i][j]);
		}
		printf("%20.2f", averageRating(i));
	}
	highestRatings();
	lowestRatings();
}

